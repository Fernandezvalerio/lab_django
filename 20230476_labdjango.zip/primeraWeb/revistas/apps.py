from django.apps import AppConfig


class RevistasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'revistas'
